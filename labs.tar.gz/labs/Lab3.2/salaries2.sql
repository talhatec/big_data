use test;

drop table if exists salaries2;

create table salaries2 (
gender varchar(1),
age int,
salary double,
zipcode int);
